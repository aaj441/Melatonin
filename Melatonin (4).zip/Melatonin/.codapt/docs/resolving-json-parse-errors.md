If a client side error appears that looks like this:

`JSON Parse error: Unrecognized token '<'`

Check the server-side logs. This usually means there's an error on the server side.
