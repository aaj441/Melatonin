export function CosmicBackground() {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {/* Gradient overlays */}
      <div className="absolute inset-0 bg-cosmic-gradient opacity-50" />
      
      {/* Ethereal glow effects */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-ethereal-glow rounded-full blur-3xl opacity-30 animate-float" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-ethereal-glow rounded-full blur-3xl opacity-20 animate-float" style={{ animationDelay: '2s' }} />
      
      {/* Floating particles */}
      {Array.from({ length: 20 }).map((_, i) => (
        <div
          key={i}
          className="absolute w-1 h-1 bg-ethereal-purple rounded-full constellation-bg"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            animationDelay: `${Math.random() * 4}s`,
          }}
        />
      ))}
    </div>
  );
}
