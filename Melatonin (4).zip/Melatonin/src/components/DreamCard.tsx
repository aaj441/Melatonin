import { MysticalCard } from './MysticalCard';
import { ArchetypeIcon } from './ArchetypeIcon';
import { Calendar, Sparkles, Volume2, Share2 } from 'lucide-react';
import { useState } from 'react';
import { ShareDreamModal } from './ShareDreamModal';

interface DreamCardProps {
  dream: {
    id: number;
    title: string;
    content: string;
    recordedAt: Date;
    mood?: string | null;
    energy?: number | null;
    voiceUrl?: string | null;
    symbols: Array<{
      id: number;
      symbolText: string;
      archetype?: {
        name: string;
        jungianType: string | null;
      } | null;
    }>;
    insights: Array<{
      id: number;
      content: string;
      culturalLens: string | null;
    }>;
  };
  userId?: number;
  onSelect?: () => void;
}

export function DreamCard({ dream, userId, onSelect }: DreamCardProps) {
  const [showInsights, setShowInsights] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  
  return (
    <MysticalCard onClick={onSelect} className="hover:scale-[1.02] transition-transform">
      <div className="space-y-4">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h3 className="text-xl font-mystical text-ethereal-purple mb-2">{dream.title}</h3>
            <div className="flex items-center gap-4 text-sm text-cosmic-purple">
              <span className="flex items-center gap-1">
                <Calendar size={14} />
                {new Date(dream.recordedAt).toLocaleDateString()}
              </span>
              {dream.mood && <span>• {dream.mood}</span>}
              {dream.energy && <span>• Energy: {dream.energy}/10</span>}
            </div>
          </div>
          {dream.voiceUrl && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                const audio = new Audio(dream.voiceUrl!);
                audio.play();
              }}
              className="p-2 rounded-full bg-cosmic-indigo/30 hover:bg-cosmic-indigo/50 transition-colors"
            >
              <Volume2 size={18} className="text-ethereal-purple" />
            </button>
          )}
          {userId && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowShareModal(true);
              }}
              className="p-2 rounded-full bg-cosmic-indigo/30 hover:bg-cosmic-indigo/50 transition-colors"
              title="Share to circle"
            >
              <Share2 size={18} className="text-ethereal-purple" />
            </button>
          )}
        </div>
        
        {/* Content Preview */}
        <p className="text-ethereal-silver/80 line-clamp-3">
          {dream.content}
        </p>
        
        {/* Symbols */}
        {dream.symbols.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {dream.symbols.slice(0, 5).map((symbol) => (
              <div
                key={symbol.id}
                className="flex items-center gap-2 px-3 py-1 rounded-full bg-cosmic-indigo/20 border border-cosmic-purple/30"
              >
                {symbol.archetype && (
                  <ArchetypeIcon archetypeName={symbol.archetype.name} size={16} />
                )}
                <span className="text-sm text-ethereal-purple">{symbol.symbolText}</span>
              </div>
            ))}
            {dream.symbols.length > 5 && (
              <span className="text-sm text-cosmic-purple">+{dream.symbols.length - 5} more</span>
            )}
          </div>
        )}
        
        {/* Insights Toggle */}
        {dream.insights.length > 0 && (
          <div>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowInsights(!showInsights);
              }}
              className="flex items-center gap-2 text-sm text-ethereal-purple hover:text-ethereal-gold transition-colors"
            >
              <Sparkles size={16} />
              {showInsights ? 'Hide' : 'Show'} {dream.insights.length} Insights
            </button>
            
            {showInsights && (
              <div className="mt-3 space-y-2">
                {dream.insights.slice(0, 3).map((insight) => (
                  <div
                    key={insight.id}
                    className="p-3 rounded-lg bg-cosmic-navy/50 border border-cosmic-purple/20"
                  >
                    {insight.culturalLens && (
                      <span className="text-xs text-ethereal-gold font-semibold uppercase tracking-wide">
                        {insight.culturalLens}
                      </span>
                    )}
                    <p className="text-sm text-ethereal-silver/90 mt-1">{insight.content}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
      
      {userId && (
        <ShareDreamModal
          isOpen={showShareModal}
          onClose={() => setShowShareModal(false)}
          dreamId={dream.id}
          dreamTitle={dream.title}
          userId={userId}
        />
      )}
    </MysticalCard>
  );
}
