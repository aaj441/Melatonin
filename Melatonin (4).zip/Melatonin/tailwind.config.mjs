/** @type {import('tailwindcss').Config} */
export default {
  content: ["./src/**/*.{js,jsx,ts,tsx}", "./index.html"],
  theme: {
    extend: {
      colors: {
        cosmic: {
          dark: '#0A0A14',
          darker: '#1A1A2C',
          navy: '#16213E',
          purple: '#2D1B69',
          indigo: '#4C1D95',
          violet: '#6B21A8',
        },
        ethereal: {
          purple: '#A78BFA',
          blue: '#60A5FA',
          pink: '#F472B6',
          gold: '#FBBF24',
          silver: '#E5E7EB',
        },
        mystical: {
          glow: '#C084FC',
          aura: '#818CF8',
        }
      },
      backgroundImage: {
        'cosmic-gradient': 'linear-gradient(135deg, #1A1A2C 0%, #16213E 50%, #2D1B69 100%)',
        'ethereal-glow': 'radial-gradient(circle at center, rgba(192, 132, 252, 0.15) 0%, transparent 70%)',
        'constellation': "url('data:image/svg+xml,%3Csvg width=\"100\" height=\"100\" xmlns=\"http://www.w3.org/2000/svg\"%%3E%3Ccircle cx=\"2\" cy=\"2\" r=\"1\" fill=\"%23A78BFA\" opacity=\"0.3\"/%3E%3Ccircle cx=\"50\" cy=\"75\" r=\"1\" fill=\"%23A78BFA\" opacity=\"0.3\"/%3E%3Ccircle cx=\"80\" cy=\"30\" r=\"1\" fill=\"%23A78BFA\" opacity=\"0.3\"/%3E%3C/svg%3E')",
      },
      animation: {
        'float': 'float 6s ease-in-out infinite',
        'glow': 'glow 2s ease-in-out infinite alternate',
        'shimmer': 'shimmer 3s linear infinite',
        'fade-in': 'fadeIn 0.5s ease-out',
        'slide-up': 'slideUp 0.5s ease-out',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-20px)' },
        },
        glow: {
          '0%': { boxShadow: '0 0 20px rgba(192, 132, 252, 0.3)' },
          '100%': { boxShadow: '0 0 40px rgba(192, 132, 252, 0.6)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-1000px 0' },
          '100%': { backgroundPosition: '1000px 0' },
        },
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(20px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
      },
      fontFamily: {
        mystical: ['Cinzel', 'serif'],
        body: ['Inter', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        'glow': '0 0 30px rgba(192, 132, 252, 0.5)',
        'glow-lg': '0 0 60px rgba(192, 132, 252, 0.6)',
        'ethereal': '0 8px 32px rgba(192, 132, 252, 0.2)',
      }
    },
  },
  plugins: [
    require('@tailwindcss/forms'),
    require('@tailwindcss/typography'),
  ],
};
